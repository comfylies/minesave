# Helper script to start server
import subprocess
s = subprocess.run(["java", "-Xmx2G", "-jar", "server.jar"])
