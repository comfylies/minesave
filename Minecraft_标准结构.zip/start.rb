# Server launcher
puts "Starting Minecraft server..."
system "java -Xmx2G -jar server.jar"
