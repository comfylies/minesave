Player advancement data stored here.
